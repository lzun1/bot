const { Client, GatewayIntentBits, Collection, Partials } = require("discord.js");
console.clear();

// Criando o cliente do Discord
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    // adicione mais intents conforme necessário
  ],
  partials: [
    Partials.Channel, 
    Partials.Message,
    Partials.Reaction
    // adicione mais partials conforme necessário
  ]
});

// Criando a coleção de comandos do bot
client.slashCommands = new Collection();

// Importando o token
const { token } = require("../config.json");
client.login(token);

// Inicializando eventos
const evento = require("./handler/Events");
evento.run(client);
require("./handler/index")(client);

// Lidando com erros não tratados
process.on('unhandledRejection', (reason, promise) => {
  console.log(`🚫 Erro Detectado:\n\n` + reason, promise);
});

process.on('uncaughtException', (error, origin) => {
  console.log(`🚫 Erro Detectado:\n\n` + error, origin);
});
